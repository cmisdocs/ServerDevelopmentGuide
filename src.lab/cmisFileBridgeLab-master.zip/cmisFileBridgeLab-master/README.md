cmisFileBridgeLab
=================

lab version of cmisFileBridge - code has student exercises embedded

This code will not run until the student exercises are completed. 


